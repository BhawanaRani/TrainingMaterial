package com.exilant.day4.StrategyPattern;

public interface Payment {
	public void pay(int amount);

}
