package com.exilant.day4.FilterPattern;

import java.util.List;

public interface ICriteria {
public List<Person>  meetCriteria(List<Person> persons);
}
